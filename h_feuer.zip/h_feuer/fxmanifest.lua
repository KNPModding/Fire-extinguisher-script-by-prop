fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Hyper'
description 'Feuerlöscher Skript per Prop | KNP Modding'
version '1.0.0'

client_script 'client.lua'
server_script 'server.lua'

dependencies {
    "es_extended"
}
