ESX = nil

Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Citizen.Wait(0)
    end
end)

local isNearFireExtinguisher = false

-- Funktion zum Überprüfen der Nähe des Spielers zum Feuerlöscher-Modell
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        local playerPed = GetPlayerPed(-1)
        local playerCoords = GetEntityCoords(playerPed)
        local object = GetClosestObjectOfType(playerCoords, 0.6, GetHashKey("prop_fire_exting_2a"), false, false, false) -- Sucht nach dem Feuerlöscher-Modell in der Nähe des Spielers
        
        if DoesEntityExist(object) then
            isNearFireExtinguisher = true
            ESX.ShowHelpNotification("Drücke ~INPUT_CONTEXT~ um den Feuerlöscher zu nehmen.")
            if IsControlJustReleased(0, 38) then -- "E" Taste
                GiveWeaponToPed(playerPed, GetHashKey("WEAPON_FIREEXTINGUISHER"), 200, false, true) -- Feuerlöscher als Waffe hinzufügen
                ESX.ShowNotification("Du hast einen Feuerlöscher genommen.")
                DeleteObject(object) -- Feuerlöscher-Objekt entfernen, damit es nicht erneut genommen werden kann
            end
        else
            isNearFireExtinguisher = false
        end
    end
end)